﻿using System;
using NationalInstruments.DAQmx;

namespace MouseBrainImaging
{
    class Shutter
    {
        /*
        ***********************************************************************
        * constants
        ***********************************************************************
        */
        private const double MAX_VOLTAGE2 = 5;
        private const double MIN_VOLTAGE2 = 0;

        /*
        ***********************************************************************
        * variables
        ***********************************************************************
        */
        private NationalInstruments.DAQmx.Task _task2 = null;
        private string _pinName2 = "Dev1/ao0";
        AnalogSingleChannelWriter _trigger2 = null;

        /*
        ***********************************************************************
        * constructor
        ***********************************************************************
        */
        public Shutter()
        {
        }
        public Shutter(string pinName2)
        {
            _pinName2 = pinName2;
        }

        /*
        ***********************************************************************
        * ionterface
        ***********************************************************************
        */
        public void init()
        {
            try
            {
                _task2 = new Task();
                _task2.AOChannels.CreateVoltageChannel(
                    _pinName2,
                    "aoChannel",
                    MIN_VOLTAGE2,
                    MAX_VOLTAGE2,
                    AOVoltageUnits.Volts);
                _trigger2 = new AnalogSingleChannelWriter(_task2.Stream);
            }
            catch
            {
                throw;
            }
        }

        public void close()
        {
            try
            {
                _task2.Dispose();
            }
            catch
            {
                throw;
            }
        }

        public void OnShutter()
        {
            try
            {
                if (_trigger2 == null)
                    return;
                _trigger2.WriteSingleSample(true, 5.0);
                _trigger2.WriteSingleSample(true, 0.0);
            }
            catch
            {
                throw;
            }
        }

        public void OffShutter()
        {
            try
            {
                if (_trigger2 == null)
                    return;
                _trigger2.WriteSingleSample(true, 5.0);
                _trigger2.WriteSingleSample(true, 0.0);
            }
            catch
            {
                throw;
            }
        }
    }
}
