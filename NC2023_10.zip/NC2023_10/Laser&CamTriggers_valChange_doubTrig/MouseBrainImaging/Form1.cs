﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Timers;
using System.Diagnostics;


namespace MouseBrainImaging
{
    public partial class Form1 : Form
    {
        bool flag_externalTrigCams = true;
        private float camTrigOnPeriod = 200; //ms
        private float camTrigOffPeriod = 200; //ms
        private System.Timers.Timer _timerCamTriggerOff = null;
        private System.Timers.Timer _timerCamTriggerOn = null;
        bool camTrig_pressed = false;

        /*
        ***********************************************************************
        * 
        ***********************************************************************
        */

        private LaserTrigger _laserTrigger = null;
        private Shutter _shutter = null;



        public Form1()
        {
            InitializeComponent();

        }



        /*
        ***********************************************************************
        * Window Events
        ***********************************************************************
        */
        //
        // Form loaded
        //
        private void Form1_Load(object sender, EventArgs e)
        {


            _laserTrigger = new LaserTrigger();
            _laserTrigger.init();

            _shutter = new Shutter();
            _shutter.init();


        }
        //
        // Form closed
        //
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

            if (_laserTrigger != null) _laserTrigger.close();
            if (_shutter != null) _shutter.close();



        }
    
       

        private void button1_Click(object sender, EventArgs e)
        {
            _laserTrigger.onLaser();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _laserTrigger.offLaser();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            _shutter.OnShutter();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            _shutter.OffShutter();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            /*If we use the camera timer*/
            if (flag_externalTrigCams && camTrig_pressed==false)
            {
                Trace.WriteLine("CAM TRIGGER");
                camTrig_pressed = true;
                _laserTrigger.onCamTrig();
                //_laserTrigger.offLaser();
                //Turn on LaserOn timer (The period which turns on the laser before imaging)
                _timerCamTriggerOn = new System.Timers.Timer(camTrigOnPeriod);//Time of this period
                _timerCamTriggerOn.Elapsed += new ElapsedEventHandler(CamTrigOn_Elapsed);
                _timerCamTriggerOn.Start();

                //Define Off timer (The period which keeps laser off and shutter on, no imaging)
                _timerCamTriggerOff = new System.Timers.Timer(camTrigOffPeriod);//Time of this period
                _timerCamTriggerOff.Elapsed += new ElapsedEventHandler(CamTrigOff_Elapsed);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            flag_externalTrigCams = false;
            _laserTrigger.offCamTrig();
            _laserTrigger.onLaser();
        }

        private void CamTrigOn_Elapsed(object sender, ElapsedEventArgs e)
        {
            _timerCamTriggerOn.Stop();
            _laserTrigger.offCamTrig();
            _laserTrigger.onLaser();
            _timerCamTriggerOff.Start();
        }


        private void CamTrigOff_Elapsed(object sender, ElapsedEventArgs e)
        {
            _laserTrigger.offLaser();
            _laserTrigger.onCamTrig();
            _timerCamTriggerOff.Stop();
            _timerCamTriggerOn.Start();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            //frequency

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            //duty cycle
        }
    }
}
