﻿using System;
using NationalInstruments.DAQmx;

namespace MouseBrainImaging
{
    class LaserTrigger
    {
        /*
        ***********************************************************************
        * constants
        ***********************************************************************
        */
        private const double MAX_VOLTAGE = 5;
        private const double MIN_VOLTAGE = 0; 

        /*
        ***********************************************************************
        * variables
        ***********************************************************************
        */
        private Task _task = null;
        private string _pinName = "Dev1/ao0";//ao1 for continuous, ao0 for sq wave trig
        AnalogSingleChannelWriter _trigger = null;

        private Task _taskCamTrig = null;
        private string _pinNameCamTrig = "Dev1/ao1";
        AnalogSingleChannelWriter _triggerCam = null;

        /*
        ***********************************************************************
        * constructor
        ***********************************************************************
        */
        public LaserTrigger() {
        }

        public LaserTrigger(string pinName)
        {
            _pinName = pinName;
        }

        /*
        ***********************************************************************
        * ionterface
        ***********************************************************************
        */
        public void init() {
            try {
                _task = new Task();
                _task.AOChannels.CreateVoltageChannel(
                    _pinName, 
                    "aoChannel",
                    MIN_VOLTAGE, 
                    MAX_VOLTAGE,
                    AOVoltageUnits.Volts);
                _trigger = new AnalogSingleChannelWriter(_task.Stream);

                _taskCamTrig = new Task();
                _taskCamTrig.AOChannels.CreateVoltageChannel(
                    _pinNameCamTrig,
                    "aoChannel",
                    MIN_VOLTAGE,
                    MAX_VOLTAGE,
                    AOVoltageUnits.Volts);
                _triggerCam = new AnalogSingleChannelWriter(_taskCamTrig.Stream);
            } catch {
                throw;
            }
        }

        public void close()
        {
            try {
                _task.Dispose();
            }
            catch {
                throw;
            }
        }

        public void onLaser()
        {
            try {
                if(_trigger == null)
                    return;
                //_trigger.WriteSingleSample(true, 5);
                _trigger.WriteSingleSample(true, 3.3);
            } catch {
                throw;
            }
        }

        public void offLaser()
        {
            try {
                if(_trigger == null)
                    return;
                _trigger.WriteSingleSample(true, 0.0);
                //_trigger.WriteSingleSample(true, 0.0);
            } catch {
                throw;
            }
        }

        public void onCamTrig()
        {
            try
            {
                if (_triggerCam == null)
                    return;

                //_triggerCam.WriteSingleSample(true, 5);
                _triggerCam.WriteSingleSample(true, 3.4);


            }
            catch
            {
                throw;
            }
        }

        public void offCamTrig()
        {
            try
            {
                if (_triggerCam == null)
                    return;
                _triggerCam.WriteSingleSample(true, 0);

            }
            catch
            {
                throw;
            }
        }
    }
}
