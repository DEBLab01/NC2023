﻿using System;
using System.Drawing.Printing;
using NationalInstruments.DAQmx;

namespace MouseBrainImaging
{
    class LaserTrigger
    {
        /*
        ***********************************************************************
        * constants
        ***********************************************************************
        */
        private const double MAX_VOLTAGE = 3.3;//5;
        private const double MIN_VOLTAGE = -3.3;//0; 

        /*
        ***********************************************************************
        * variables
        ***********************************************************************
        */
        private Task _task = null;
        private string _pinName = "Dev1/ao1";
        AnalogSingleChannelWriter _trigger = null;

        /*
        ***********************************************************************
        * constructor
        ***********************************************************************
        */
        public LaserTrigger() {
        }

        public LaserTrigger(string pinName)
        {
            _pinName = pinName;
        }

        /*
        ***********************************************************************
        * ionterface
        ***********************************************************************
        */
        public void init() {
            try {
                _task = new Task();
                _task.AOChannels.CreateVoltageChannel(
                    _pinName,
                    "aoChannel",
                    MIN_VOLTAGE,
                    MAX_VOLTAGE,
                    AOVoltageUnits.Volts);
                _trigger = new AnalogSingleChannelWriter(_task.Stream);
            } catch {
                throw;
            }
        }

        public void close()
        {
            try {
                _task.Dispose();
            }
            catch {
                throw;
            }
        }

        public void onLaser()
        {
            try {
                if(_trigger == null)
                    return;
                _trigger.WriteSingleSample(true, 3.3);
            } catch {
                throw;
            }
        }

        public void offLaser()
        {
            try {
                if(_trigger == null)
                    return;
                _trigger.WriteSingleSample(true, 0.0);
            } catch {
                throw;
            }
        }
    }
}
