﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Timers;
using System.Diagnostics;


namespace MouseBrainImaging
{
    public partial class Form1 : Form
    {


        /*
        ***********************************************************************
        * 
        ***********************************************************************
        */

        private LaserTrigger _laserTrigger = null;
        private Shutter _shutter = null;



        public Form1()
        {
            InitializeComponent();

        }



        /*
        ***********************************************************************
        * Window Events
        ***********************************************************************
        */
        //
        // Form loaded
        //
        private void Form1_Load(object sender, EventArgs e)
        {


            _laserTrigger = new LaserTrigger();
            _laserTrigger.init();

            _shutter = new Shutter();
            _shutter.init();


        }
        //
        // Form closed
        //
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

            if (_laserTrigger != null) _laserTrigger.close();
            if (_shutter != null) _shutter.close();



        }
    
       

        private void button1_Click(object sender, EventArgs e)
        {
            _laserTrigger.onLaser();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _laserTrigger.offLaser();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            _shutter.OnShutter();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            _shutter.OffShutter();
        }



    }
}
