function fns = TrajectoryFieldNames()

fns = {
  'x'
  'y'
  'theta'
  'a'
  'b'
  'timestamps'
  'x_mm'
  'y_mm'
  'a_mm'
  'b_mm'
  'theta_mm'
  'dt'
  'sex'
  };
