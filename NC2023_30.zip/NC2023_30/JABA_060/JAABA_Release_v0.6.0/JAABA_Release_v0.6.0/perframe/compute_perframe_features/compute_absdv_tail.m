% template computing absolute values of attributes
function [data,units] = compute_absdv_tail(trx,n)

[data,units] = compute_abs__template(trx, n, 'dv_tail');
