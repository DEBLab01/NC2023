% template computing absolute values of attributes
function [data,units] = compute_absdu_tail(trx,n)

[data,units] = compute_abs__template(trx, n, 'du_tail');
