% template computing absolute values of attributes
function [data,units] = compute_absangleonclosestfly(trx,n)

[data,units] = compute_abs__template(trx, n, 'angleonclosestfly');
