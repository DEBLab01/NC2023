function result=isnonempty(thing)
result=~isempty(thing);
end
