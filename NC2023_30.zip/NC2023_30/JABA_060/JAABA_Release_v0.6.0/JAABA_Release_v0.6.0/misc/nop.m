function nop(varargin)
% this is a function that does nothing and returns nothing. 
end
