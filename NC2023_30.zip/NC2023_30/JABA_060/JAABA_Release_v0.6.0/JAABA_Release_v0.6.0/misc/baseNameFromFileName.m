function baseName=baseNameFromFileName(fileName)

[~,baseName]=fileparts(fileName);

end
