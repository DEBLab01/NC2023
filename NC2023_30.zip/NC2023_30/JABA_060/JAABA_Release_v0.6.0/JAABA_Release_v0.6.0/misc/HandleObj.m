classdef HandleObj < handle
  properties
    data
  end
end