function ctrax_matlab_misc_check()

fprintf('Yes, you have the Ctrax matlab/misc code!\n');

