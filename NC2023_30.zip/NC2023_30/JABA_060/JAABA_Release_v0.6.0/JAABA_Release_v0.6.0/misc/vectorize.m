function v = vectorize(m)

v = m(:);