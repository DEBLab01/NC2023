function baseName=fileBaseName(fileName)

[~,baseName]=myfileparts(fileName);

end