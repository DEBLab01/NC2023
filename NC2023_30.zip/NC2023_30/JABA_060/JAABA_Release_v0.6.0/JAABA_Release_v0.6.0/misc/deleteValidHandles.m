function deleteValidHandles(h)
delete(h(ishandle(h)));