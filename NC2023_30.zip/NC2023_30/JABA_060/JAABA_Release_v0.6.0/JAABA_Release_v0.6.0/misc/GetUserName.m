function username = GetUserName()

username = char(java.lang.System.getProperty('user.name'));
