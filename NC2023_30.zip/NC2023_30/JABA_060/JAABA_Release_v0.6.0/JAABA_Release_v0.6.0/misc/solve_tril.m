% use the lightspeed version if available -- it is faster
function v = solve_tril(T,b)

v = T\b;