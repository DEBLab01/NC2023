function str=offIff(test)

if test,
  str='off';
else
  str='on';
end

return
