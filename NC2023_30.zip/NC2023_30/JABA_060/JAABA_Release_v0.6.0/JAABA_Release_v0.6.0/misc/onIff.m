function str=onIff(test)

if test,
  str='on';
else
  str='off';
end

return
