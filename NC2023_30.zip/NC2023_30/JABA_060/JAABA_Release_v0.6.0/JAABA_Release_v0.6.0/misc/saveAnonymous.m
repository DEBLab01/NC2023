function saveAnonymous(fileName,x)  %#ok

save(fileName,'x','-mat');

end
